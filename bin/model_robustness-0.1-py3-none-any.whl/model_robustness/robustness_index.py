from __future__ import division
import pandas as pd
from utils.common import *
from utils.log import *
from utils.timer import *
from sklearn.utils import resample
from .helpers.evaluation import EvaluationHelper


setup_logger(log_level="DEBUG")

class RobustnessIndex():
    """
    # CHECK THE ROBUSTNESS OF THE MODEL ON THE GIVEN DATA SET
    # Method:
    # 1. Using bootstraping, sample as many as possible
    # 2. Predict on these samples
    # 3. Calculate the evaluation metrics
    # 4. Calculate the mean, SE, and CI of these metrics
    """

    def __init__(self):
        """

        """
        pass

    def run(self, data, targetCol, model, nsamples=10, nrecods=100, cls=[95], random_state=None):
        """
        The function will create nsamples of size nrecords with repetition using bootstrapping.
        :param nsamples:
        :param nrecods:
        :return:
        """
        est_auc = []
        est_f1 = []
        est_prec = []
        est_recall = []
        est_acc = []

        for i in range(1, nsamples + 1):
            logging.info("Sampling " + str(i))
            data_boot = resample(data, replace=True, n_samples=nrecods, random_state=random_state)

            preds = model.predict(data_boot)
            y_preds = preds[:, 0]
            y_pred_probs = preds[:, 2]
            y_pred_probs0 = preds[:, 1]
            y_act = [targetCol]
            # make necessary transformation for h20 frames
            if is_h2o_frame(y_preds):
                y_preds = convert_h2o_list(y_preds)

            if is_h2o_frame(y_pred_probs):
                y_pred_probs = convert_h2o_list(y_pred_probs)

            if is_h2o_frame(y_pred_probs0):
                y_pred_probs0 = convert_h2o_list(y_pred_probs0)

            if is_h2o_frame(y_act):
                y_act = convert_h2o_list(y_act)

            auc, f1, prec, recl, acc = EvaluationHelper.get_stats(y_act, y_preds)
            est_auc.append(auc)
            est_f1.append(f1)
            est_prec.append(prec)
            est_recall.append(recl)
            est_acc.append(acc)

        # We have estimations from multiple sample. Now get the mean, se, and CI
        acc_df = self.get_evaluation_stats("Accuracy", est_acc, cls)
        f1_df = self.get_evaluation_stats("F1", est_f1, cls)
        acc_df.append(f1_df)
        auc_df = self.get_evaluation_stats("AUC", est_auc, cls)
        acc_df.append(auc_df)
        return acc_df


    def get_evaluation_stats(self, metric, estimates, cls):
        """
        returns a list that contains mean, se and various confidence levels
        :param estimates:
        :param cls:
        :return:
        """
        cols = ['Statistic', 'Mean', 'SE', 'CL', 'LB', 'UB', 'CI', 'Robustness_Index']
        est_df = pd.DataFrame(columns=cols)
        # loop through the confidence interval
        for cl in cls:
            m, se, lb, ub = EvaluationHelper.get_mean_se_ci(estimates, cl)
            ci_lbl = str(round(lb, 4)) + " - " + str(round(ub, 4))
            est_df.append(pd.DataFrame(
                [[metric, round(mn, 4), round(stde, 4), cl, lb, ub, ci_lbl, round((ub - lb), 4)]],
                columns=cols))
        return est_df


    def get_evaluation_stats1(self, metric, estimates, cls):
        """
        returns a list that contains mean, se and various confidence levels
        :param estimates:
        :param cls:
        :return:
        """
        cols = ['Statistic', 'Mean', 'SE']
        est_df = pd.DataFrame(columns=cols)
        ci_lst, ci_lb, ci_ub = []
        # loop through the confidence interval
        for cl in cls:
            cols.append('CI@' + str(cl))
            # Accuracy
            m, se, lb, ub = EvaluationHelper.get_mean_se_ci(estimates, cl)
            ci_lst.append(str(round(lb, 4)) + " - " + str(round(ub, 4)))
            mn = m
            stde = se
            ci_lb = lb
            ci_ub = ub

        est_df.append(pd.DataFrame(
            [[metric, round(mn, 4), round(stde, 4), ci_lst]],
            columns=cols))
        return est_df
